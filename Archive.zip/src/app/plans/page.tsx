"use client";

import { useState } from "react";
import Script from "next/script";
import { CheckCircle2, Zap, Crown } from "lucide-react";

declare global {
  interface Window {
    Razorpay: any;
  }
}

export default function PlansPage() {
  const [isProcessing, setIsProcessing] = useState(false);
  const [isRazorpayLoaded, setIsRazorpayLoaded] = useState(false);

  const plans = [
    {
      id: "plan_monthly",
      name: "Monthly Plan",
      price: "1,200",
      amount: 1200 * 100, // Razorpay takes amounts in paise
      duration: "per month",
      description: "Perfect for getting started with all essential features.",
      icon: <Zap className="w-10 h-10 text-blue-500 mb-4" />,
      features: [
        "Full Admin Panel Access",
        "Website Template Management",
        "Basic Analytics",
        "Email Support",
      ],
      color: "from-blue-500 to-cyan-400",
      isPopular: false,
    },
    {
      id: "plan_yearly",
      name: "Yearly Plan",
      price: "14,400",
      amount: 14400 * 100, // 14400 rupees
      duration: "per year",
      description: "Best value for long-term growth. Includes premium perks.",
      icon: <Crown className="w-10 h-10 text-purple-500 mb-4" />,
      features: [
        "Everything in Monthly",
        "Priority 24/7 Support",
        "Advanced SEO Tools",
        "Custom Domain Setup",
      ],
      color: "from-purple-500 to-pink-500",
      isPopular: true,
    },
  ];

  const handlePayment = async (plan: typeof plans[0]) => {
    if (!isRazorpayLoaded) {
      alert("Payment gateway is loading, please try again in a moment.");
      return;
    }
    
    setIsProcessing(true);

    try {
      // Step 1: Create an Order on our backend
      const orderResponse = await fetch("/plans/api/order", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          amount: plan.amount,
          planName: plan.name,
        }),
      });

      const orderData = await orderResponse.json();

      if (!orderResponse.ok) {
        throw new Error(orderData.error || "Failed to create order");
      }

      // Step 2: Open Razorpay Checkout
      const options = {
        key: process.env.NEXT_PUBLIC_RAZORPAY_KEY_ID, // Use the real key from environment
        amount: orderData.amount,
        currency: orderData.currency,
        name: "EdDesk Platform",
        description: `${plan.name} Subscription`,
        order_id: orderData.id, // Mandatory for production/verified flow
        handler: async function (response: any) {
          try {
            // Step 3: Verify the payment on our backend
            const verifyResponse = await fetch("/plans/api/verify", {
              method: "POST",
              headers: { "Content-Type": "application/json" },
              body: JSON.stringify({
                razorpay_order_id: response.razorpay_order_id,
                razorpay_payment_id: response.razorpay_payment_id,
                razorpay_signature: response.razorpay_signature,
              }),
            });

            const verifyData = await verifyResponse.json();

            if (verifyResponse.ok && verifyData.success) {
              alert(`Payment Verified! Welcome to EdDesk ${plan.name}.`);
              // Redirect to onboarding or dashboard
            } else {
              alert("Payment verification failed. Please contact support.");
            }
          } catch (err) {
            console.error("Verification Error:", err);
            alert("An error occurred during verification.");
          } finally {
            setIsProcessing(false);
          }
        },
        prefill: {
          name: "Super Admin",
          email: "superadmin@eddesk.in",
          contact: "9999999999"
        },
        theme: {
          color: plan.isPopular ? "#A855F7" : "#3B82F6"
        },
        modal: {
          ondismiss: function() {
            setIsProcessing(false);
          }
        }
      };

      const rzp = new window.Razorpay(options);
      rzp.on('payment.failed', function (response: any){
        alert("Payment Failed: " + response.error.description);
        setIsProcessing(false);
      });
      rzp.open();
    } catch (error: any) {
      console.error("Payment Error:", error);
      alert(error.message || "Failed to initialize payment");
      setIsProcessing(false);
    }
  };

  return (
    <div className="min-h-screen bg-slate-50 dark:bg-slate-950 flex items-center justify-center p-4">
      {/* Razorpay Script */}
      <Script 
        src="https://checkout.razorpay.com/v1/checkout.js" 
        onLoad={() => setIsRazorpayLoaded(true)}
      />

      <div className="w-full max-w-6xl mx-auto py-12 md:py-24">
        {/* Header Section */}
        <div className="text-center mb-16 space-y-4 animate-in slide-in-from-bottom-5 fade-in duration-700">
          <h1 className="text-4xl md:text-5xl font-extrabold tracking-tight text-slate-900 dark:text-white">
            Choose Your <span className="text-transparent bg-clip-text bg-gradient-to-r from-blue-600 to-purple-600">Perfect Plan</span>
          </h1>
          <p className="text-lg text-slate-600 dark:text-slate-400 max-w-2xl mx-auto">
            Unlock the full potential of your school website with our flexible pricing options.
            No hidden fees, cancel anytime.
          </p>
        </div>

        {/* Pricing Cards */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8 max-w-4xl mx-auto">
          {plans.map((plan, index) => (
            <div 
              key={plan.id}
              className={`relative group bg-white dark:bg-slate-900 rounded-3xl p-8 shadow-sm hover:shadow-2xl transition-all duration-500 transform hover:-translate-y-2 border 
                ${plan.isPopular ? 'border-purple-500/50 dark:border-purple-500/50' : 'border-slate-200 dark:border-slate-800'}
                animate-in slide-in-from-bottom-${8 + index * 4} fade-in duration-700 fill-mode-both
              `}
              style={{ animationDelay: `${index * 150}ms` }}
            >
              {plan.isPopular && (
                <div className="absolute -top-4 left-0 right-0 flex justify-center">
                  <span className="bg-gradient-to-r from-purple-500 to-pink-500 text-white text-xs font-bold px-4 py-1.5 rounded-full uppercase tracking-wider shadow-lg animate-pulse">
                    Most Popular
                  </span>
                </div>
              )}
              
              <div className="mb-8">
                {plan.icon}
                <h3 className="text-2xl font-bold text-slate-900 dark:text-white mb-2">{plan.name}</h3>
                <p className="text-slate-500 dark:text-slate-400 text-sm h-10">{plan.description}</p>
              </div>

              <div className="mb-8">
                <div className="flex items-baseline gap-2">
                  <span className="text-5xl font-extrabold text-slate-900 dark:text-white">₹{plan.price}</span>
                  <span className="text-slate-500 dark:text-slate-400">{plan.duration}</span>
                </div>
              </div>

              <ul className="space-y-4 mb-8">
                {plan.features.map((feature, fIndex) => (
                  <li key={fIndex} className="flex items-center gap-3 text-slate-600 dark:text-slate-300 group-hover:translate-x-1 transition-transform duration-300" style={{ transitionDelay: `${fIndex * 50}ms` }}>
                    <CheckCircle2 className="w-5 h-5 text-green-500 flex-shrink-0" />
                    <span>{feature}</span>
                  </li>
                ))}
              </ul>

              <button
                onClick={() => handlePayment(plan)}
                disabled={isProcessing}
                className={`w-full py-4 rounded-xl font-bold text-white transition-all duration-300 
                  bg-gradient-to-r ${plan.color} hover:opacity-90 active:scale-95 shadow-lg relative overflow-hidden
                  ${isProcessing ? 'opacity-50 cursor-not-allowed' : ''}
                `}
              >
                {/* Button shine effect */}
                <div className="absolute inset-0 -translate-x-[150%] animate-[shimmer_2s_infinite] bg-gradient-to-r from-transparent via-white/20 to-transparent skew-x-12" />
                <span className="relative">{isProcessing ? 'Processing...' : 'Choose Plan'}</span>
              </button>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
